import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Loader2 } from "lucide-react";
import { motion } from "motion/react";

export function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    login(email);
    navigate("/");
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4 relative overflow-hidden">
      {/* Abstract Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,#f1f5f9,transparent)] opacity-60 pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 pointer-events-none" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-[400px] relative z-10"
      >
        <div className="mb-12 text-center">
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="inline-block"
          >
            <h1 className="text-4xl font-serif tracking-tight text-black mb-2">
              NEXUS
            </h1>
            <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-black/20 to-transparent" />
          </motion.div>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="text-black text-sm mt-4 tracking-wide uppercase font-medium"
          >
            Enterprise Dashboard Access
          </motion.p>
        </div>

        <motion.form 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          onSubmit={handleSubmit} 
          className="space-y-5"
        >
          <div className="space-y-1.5">
            <label className="text-[11px] uppercase tracking-wider font-bold text-black ml-1">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-12 bg-white border border-zinc-300 rounded-lg px-4 text-black placeholder:text-zinc-500 focus:outline-none focus:border-black focus:ring-1 focus:ring-black transition-all duration-300"
              placeholder="name@nexus.com"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] uppercase tracking-wider font-bold text-black ml-1">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full h-12 bg-white border border-zinc-300 rounded-lg px-4 text-black placeholder:text-zinc-500 focus:outline-none focus:border-black focus:ring-1 focus:ring-black transition-all duration-300"
              placeholder="••••••••"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center gap-2 cursor-pointer group">
              <div className="w-4 h-4 rounded border border-zinc-400 bg-white flex items-center justify-center transition-colors group-hover:border-black">
                <input type="checkbox" className="appearance-none" />
                <div className="w-2 h-2 bg-black rounded-[1px] opacity-0 check-indicator" />
              </div>
              <span className="text-xs text-zinc-600 group-hover:text-black transition-colors font-medium">Remember me</span>
            </label>
            <a href="#" className="text-xs text-zinc-600 hover:text-black transition-colors font-medium">Forgot password?</a>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 bg-black text-white font-medium rounded-lg hover:bg-zinc-800 active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed mt-6"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                Sign In <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </motion.form>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-center text-xs text-zinc-500 mt-12 font-medium"
        >
          Protected by enterprise-grade security.
          <br />
          <span className="hover:text-black cursor-pointer transition-colors">Privacy Policy</span> • <span className="hover:text-black cursor-pointer transition-colors">Terms of Service</span>
        </motion.p>
      </motion.div>
    </div>
  );
}
