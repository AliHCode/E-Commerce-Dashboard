import { useState } from "react";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Users, 
  Settings as SettingsIcon, 
  Bell,
  Search,
  Menu,
  X,
  LogOut
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { BrowserRouter as Router, Routes, Route, Link, useLocation, Navigate } from "react-router-dom";
import { cn } from "@/lib/utils";

// Contexts
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ThemeProvider, useTheme } from "@/contexts/ThemeContext";
import { DataProvider } from "@/contexts/DataContext";

// Components
import { ProtectedRoute } from "@/components/ProtectedRoute";

// Pages
import { Login } from "@/pages/Login";
import { Dashboard } from "@/pages/Dashboard";
import { Orders } from "@/pages/Orders";
import { OrderDetails } from "@/pages/OrderDetails";
import { Products } from "@/pages/Products";
import { Customers } from "@/pages/Customers";
import { Settings } from "@/pages/Settings";

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <DataProvider>
          <Router>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/*" element={
                <ProtectedRoute>
                  <AppLayout />
                </ProtectedRoute>
              } />
            </Routes>
          </Router>
        </DataProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

function AppLayout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  const { theme } = useTheme();

  return (
    <div className={cn(
      "min-h-screen font-sans text-slate-900 flex transition-colors duration-200",
      theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-gray-50/50'
    )}>
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 border-r transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:inset-auto lg:flex lg:flex-col",
        theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-gray-200',
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className={cn(
          "flex h-16 items-center border-b px-6",
          theme === 'dark' ? 'border-slate-800' : 'border-gray-200'
        )}>
          <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
            <span className={cn("font-serif text-2xl tracking-tight", theme === 'dark' ? 'text-white' : 'text-black')}>
              NEXUS
            </span>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="ml-auto lg:hidden text-gray-500"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-6 px-4 space-y-1">
          <NavItem to="/" icon={LayoutDashboard} label="Dashboard" active={location.pathname === "/"} onClick={() => setIsSidebarOpen(false)} />
          <NavItem to="/orders" icon={ShoppingCart} label="Orders" active={location.pathname.startsWith("/orders")} onClick={() => setIsSidebarOpen(false)} />
          <NavItem to="/products" icon={Package} label="Products" active={location.pathname.startsWith("/products")} onClick={() => setIsSidebarOpen(false)} />
          <NavItem to="/customers" icon={Users} label="Customers" active={location.pathname.startsWith("/customers")} onClick={() => setIsSidebarOpen(false)} />
          <div className="pt-6 pb-2">
            <p className="px-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">System</p>
          </div>
          <NavItem to="/settings" icon={SettingsIcon} label="Settings" active={location.pathname === "/settings"} onClick={() => setIsSidebarOpen(false)} />
        </div>

        <div className={cn(
          "p-4 border-t",
          theme === 'dark' ? 'border-slate-800' : 'border-gray-200'
        )}>
          <div className="flex items-center gap-3">
            <img 
              src={user?.avatar || "https://picsum.photos/seed/avatar/100/100"} 
              alt="User" 
              className="w-10 h-10 rounded-full bg-gray-200"
              referrerPolicy="no-referrer"
            />
            <div className="flex-1 min-w-0">
              <p className={cn("text-sm font-medium truncate", theme === 'dark' ? 'text-slate-200' : 'text-gray-900')}>
                {user?.name || "User"}
              </p>
              <p className="text-xs text-gray-500 truncate">{user?.email || "user@example.com"}</p>
            </div>
            <button onClick={logout} className="p-2 text-gray-400 hover:text-red-500 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className={cn(
          "h-16 border-b flex items-center justify-between px-4 lg:px-8 sticky top-0 z-30",
          theme === 'dark' ? 'bg-slate-900 border-slate-800' : 'bg-white border-gray-200'
        )}>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 -ml-2 text-gray-500 hover:bg-gray-100 rounded-md"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div className="relative hidden sm:block w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search..."
                className={cn(
                  "w-full h-9 pl-9 pr-4 rounded-md border text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all",
                  theme === 'dark' 
                    ? 'bg-slate-800 border-slate-700 text-slate-200 placeholder-slate-500' 
                    : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'
                )}
              />
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/orders/:id" element={<OrderDetails />} />
            <Route path="/products" element={<Products />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function NavItem({ icon: Icon, label, active = false, to, onClick }: { icon: any, label: string, active?: boolean, to: string, onClick?: () => void }) {
  const { theme } = useTheme();
  
  return (
    <Link 
      to={to}
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
        active 
          ? "bg-indigo-50 text-indigo-600" 
          : theme === 'dark'
            ? "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
      )}
    >
      <Icon className="w-5 h-5" />
      {label}
    </Link>
  );
}
